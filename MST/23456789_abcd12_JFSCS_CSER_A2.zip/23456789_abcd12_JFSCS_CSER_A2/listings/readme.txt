Use this folder to store your computer code listings and text files for console output.

Example of including console output in your document:

\lstinputlisting[style=console-output,caption=Example-1]{listings/your_console_file.txt}


Example of including computer code in your document:

\lstinputlisting[style=octave-code,caption=Example-1]{listings/your_code_file.m}


styles available:

octave-code, python-code, c-code, console-output
